module("twitter api");
test("callback example", function() {
	stop();  //or you can use asyncTest above, which starts the test 'stopped'

	delayedAddTweets('#tweets',{'results':[strippedResult]}

	);

	setTimeout(function() {
		equal($('#tweets div').length,1);
		start();
	},550)
});

var strippedResult={
	"from_user":"EXPECTED_FROM_USER",
	"text":"EXPECTED TEXT"
};

//exercise: now write a test for the loadTweets function (with its twitter api integration) 
test("direct twitter access with wait", function() {
	expect(0);//delete this line, it's just to avoid this test failing before we start the exercise.
});
